package com.example.demo.model.service;

import com.example.demo.model.entity.CategoriaCursos;

public interface CursosCategoriasService {

    public CategoriaCursos saveCategoriasCursos(CategoriaCursos categoriaCursos);

    public void deleteCurso(Long id);



}
