package com.example.demo.view;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Testes {
    public static void main(String[] args) {

        String dtVaga = new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime());
        System.out.println(dtVaga);
    }
}
