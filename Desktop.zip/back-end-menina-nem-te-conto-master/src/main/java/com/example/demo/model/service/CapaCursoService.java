package com.example.demo.model.service;

import com.example.demo.model.entity.CapaCurso;
import com.example.demo.model.repository.CapaCursoRepository;

public interface CapaCursoService {


    CapaCurso saveCapaCurso(CapaCurso capaCurso);
}
