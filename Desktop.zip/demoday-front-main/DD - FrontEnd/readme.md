Instruções de uso:

1 - todas as imagens se encontram em "../../ASSETS/"

2 - Cores, tamanho de botões e bordas arredondadas possuem suas definições no arquivo ../../css/resize.css

3 - todos os botões e inputs relevantes possuem seus respectivos elementos "form", dos quais estão sem um "action" e "method" atribuidos;

4 - nenhuma página possue arquivo js codado, porém os elementos, textos e/ou imagens que irão ser dinamicos(mudados com o uso), possuem nomes simples e intuitivos para que não ocorram erros/esquecimento do que cada um representa;

6 - todas as unidades de medidas estão em REM (referente ao tamanho da font do root do documento - no caso, 16px) >> facilita a responsividade;

7 - Alguns componentes não funcionam do modo do qual foram pensados, devido à falta de conhecimentos em estilização, animação e js da minha parte;

8 - Qualquer página que possua erros, necessidade de retrabalho, ou falta de conteúdo, vão ser adicionados à um comentário TO-DO para facilitar o conhecimento das pendências
